// add javascript code here for web storage lab exercise
function book(name){
	this.name=name;
}

function add(){
	
	var obj_key="obj_key"+localStorage.length;
	localStorage.setItem(obj_key, JSON.stringify(new book(document.book_form.bookName.value)))
	
	window.location.reload;
}

 function clear_storage(){
	 localStorage.clear();
 }
 
function fromStorage(){
	var i;
	for (i=0; i<=localStorage.length; i++){
		var parsedObject=JSON.parse(localStorage.getItem("obj_key"+i));
		
			alert(parsedObject.name);
		
	}
		
}


