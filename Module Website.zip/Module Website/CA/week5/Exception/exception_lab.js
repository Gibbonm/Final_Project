console.log('And we\'re off');

try{
var someVar; // variable is not declared. Will cause an exception
 //document.getElementById("error_details").innerHTML="Uncaught Reference Error: someVar is not defined ";
}catch(e){
	document.getElementById("error_details").innerHTML="Uncaught Reference Error: someVar is not defined ";
}finally{
	alert("The code has finally run")
};

