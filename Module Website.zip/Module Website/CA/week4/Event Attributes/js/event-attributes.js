var elUserName=document.getElementById("username");

elUserName.onblur=checkUsername;

function checkUsername(){
	var msg = document.getElementById("username");
	//alert(msg.value.length);
	if (msg.value.length < 6){
		document.getElementById("feedback").innerHTML="Please enter at least 6 characters";
	}
	
}