function itemDone(e){
	
			var target=e.target; 
			
			var elListitem=target.parentNode; 	
			var elList=elListitem.parentNode;
			
			elList.removeChild(elListitem);

}








var el = document.getElementById('shoppingList');  // Get username input
// When it loses focus call checkUsername()
el.addEventListener('click', function(e){itemDone(e);}
, false);