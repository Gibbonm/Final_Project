var el = document.getElementById("username");
el. addEventListener('blur', checkUsername, false);


function checkUsername(){
	var msg = document.getElementById("username");
	//alert(msg.value.length);
	if (msg.value.length < 6){
		document.getElementById("feedback").innerHTML="Please enter at least 6 characters";
	}
	
}