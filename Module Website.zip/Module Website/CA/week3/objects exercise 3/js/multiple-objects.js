function Hotel (name, rooms, booked){

this.name = name;
this.rooms = rooms;
this.booked = booked;
this.checkAvailability = function() {    	
return this.rooms - this.booked;
};
}
var quayHotel = new Hotel("Quay ", 40, 25);
var parkHotel = new Hotel("Park ", 120, 77);

// Update the HTML
var elName = document.getElementById('hotel1'); // Get element
elName.textContent = quayHotel.name + "Rooms: "+ quayHotel.checkAvailability();                   // Update HTML with property of the object

//var elRooms = document.getElementById('rooms1');    // Get element
//elRooms.textContent = quayHotel.checkAvailability();   // Update HTML with property of the object

var elName = document.getElementById('hotel2'); // Get element
elName.textContent = parkHotel.name + "Rooms: "+ parkHotel.checkAvailability();                   // Update HTML with property of the object

//var elRooms = document.getElementById('rooms2');    // Get element
//elRooms.textContent = parkHotel.checkAvailability();   // Update HTML with property of the object