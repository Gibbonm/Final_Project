<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"> 
<head> 
<title>Add to and Read from the Database</title>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
</head> 
<body>

<?php
function print_form() {
echo <<<END
         <form action="$_SERVER[PHP_SELF]" method="post">

    <h3>Please put your comments below.</h3>

<input type="hidden" name="stage" value="process" >
<p>Name:</p>
<input type="text" size="30" name="WholeName" />
<p>Comment:</p>
<input type="text" size="200" name="Comment" />

<input type ="submit"  value ="Submit" >
</form>
END;    

    }
function process_form() {

print "<p>adding comment...</p>";

$Name = $_POST['WholeName'];
$Comment = $_POST['Comment'];

    if( preg_match("^[a-zA-Z]+$", $Name)) {
        if( preg_match("^[a-zA-Z0-9]_\-\'[.?!]+$", $Comment)) {
            $sql = "insert into comments1 values ( 
           '$Name', 
           '$Comment')";
           $result = mysql_query($sql) or die("Mysql query failed");
      } else {
        print "invalid name";
        }
  } else {
print "invalid characters";
 }

}

$db = mysql_connect("", "", "");
if (!$db) {
   print "Error - Could not connect to mysql";
   exit;
}  

$er = mysql_select_db("");
if (!$er) {
  print "Error - Could not connect to comments1 database";
  exit;
}

if (isset($_POST['stage']) && ('process' == $_POST['stage'])) {
   process_form();
} else {
    print_form();
}

?>

</body>
</html>