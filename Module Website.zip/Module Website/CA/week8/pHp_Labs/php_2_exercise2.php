

<?php
include_once 'handle_form.php';
  ?>


<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    

    <title>Homepage</title>
</head>
<body>
<div>Enter your information in the form below:</div><br><br><br>
<form  action="handle_form.php" method="get">
  Name:<input type="text" name="name">
  <br><br>
  Email Address:<input type="email" name="email" >
  <br>
 <input type="radio" name="gender" value="male" checked> Male
  <input type="radio" name="gender" value="female"> Female<br>
  <br>
   Age:<input type="Number" name="age">
   <br><br>
   Comments:<textarea  type="text" value="" name="comments"></textarea>
    <br><br>
    Interests:<br>
    <input type="checkbox" name="CSS" value="CSS">CSS<br>
  <input type="checkbox" name="PHP" value="php">PHP<br> 
  <input type="checkbox" name="JavaScript" value="JavaScript">JavaScript<br> 
  <input type="checkbox" name="HTML" value="HTML">HTML<br> 
<br><br><br>



  <input type="submit" value="Submit">
</form> 

    


 
</body>
</html>




