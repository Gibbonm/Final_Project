


<?php 
for ($x = 1; $x <= 5; $x++) {
    echo "Number: $x <br>";
} 
?>


