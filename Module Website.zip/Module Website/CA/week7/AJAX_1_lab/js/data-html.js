var xhr = new XMLHttpRequest(); //create AJAX object

xhr.open("GET","data/data.html",true);	//create request
xhr.send(null);		//send request

//process response

xhr.onload= function(){
	
	document.getElementById("content").innerHTML=xhr.responseText;
	
};