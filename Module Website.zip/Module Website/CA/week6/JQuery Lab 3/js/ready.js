$(document).ready(function(){
	$("#page").html("<p>Test</p>");
	
});