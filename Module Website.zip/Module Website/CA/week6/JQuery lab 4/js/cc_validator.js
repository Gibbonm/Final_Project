$(function(){

	$isValid=false; //global variable for validator result

		//credit card validator
				$('#cc_number').validateCreditCard(function(result){
						result.valid ? $isValid=true : $isValid=false;
				});

	//confirm button
	$('.confirm').on('click',function(){
		$isValid ? $(window).attr("location","confirmed.html") : alert("Not Valid CC"); 
			
	});





});


//$isValid ? $(window).attr("location","confirmed.html") : alert("Not Valid CC"); 
//$isValid ?  alert("Is a Valid CC") : alert("Not Valid CC");
