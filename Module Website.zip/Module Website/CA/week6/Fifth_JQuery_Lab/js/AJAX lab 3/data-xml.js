var xhr = new XMLHttpRequest();//create AJAX object

xhr.onload = function() {
	var response = xhr.responseXML;
	var events = response.getElementsByTagName('event');
	
	var di1='map';
	var di2='location';
	var di3='date';
	
	var newContent = '';
		for (var i=0; i < events.length; i++){
			newContent+= '<div class="event">';
			newContent+= '<img src="'+events[i].getElementsByTagName(di1)[0].firstChild.nodeValue+'"';
			newContent+= 'alt="'+events[i].getElementsByTagName(di2)[0].firstChild.nodeValue+'"/>';
			newContent+= '<p><b>'+events[i].getElementsByTagName(di2)[0].firstChild.nodeValue+'</b><br>';
			newContent+= events[i].getElementsByTagName(di3)[0].firstChild.nodeValue + '</p>';
			newContent+= '</div>';
		};
		
		document.getElementById("content").innerHTML=newContent;
	
};



xhr.open("GET","data/data.xml",true);	//create request
xhr.send(null);		//send request




























