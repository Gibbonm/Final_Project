function function1(){
	
	var x = document.getElementById("firstnumber").value;
	var y = document.getElementById("secondnumber").value;
	var a = parseInt(x);
	var b = parseInt(y);
	var z = a+b;
	
    if (a > 10) {
		alert("Number 1 must be smaller than 10");
	}else alert("The sum of the numbers is"+z);
	}
	
	 
