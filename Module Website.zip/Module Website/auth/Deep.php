<?php include_once 'resource/session.php' ?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Bootstrap -->
     
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css?family=Righteous" rel="stylesheet">
     <link href="css/custom.css" rel="stylesheet">


     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/cart.js"></script>





    <title>Deep Tissue Massage</title>
</head>
<body>
<br>
<div class="container">

<div class="jumbotron"><h1><img src="img/background.png" alt="therapy">&nbsp;&nbsp;&nbsp;Galway Physical Therapy</h1>
</div>

    <div>
<div class="panel panel-default">
    <div class="panel-body" id="nav1">
    
    <ul class="nav nav-pills">
  <li role="presentation" ><a href="index.php">Home</a></li>
  <li role="presentation"><a href="about.php">About</a></li>
  <li role="presentation"><a href="feedback.php">Contact</a></li>
   <li role="presentation"><a href="logout.php">Logout</a></li>
   <li role="presentation"><a href="forgot_password.php">Reset Password</a></li>



<form class="navbar-form navbar-right" >
        <div class="form-group">
          <p>You are logged in as <?php if(isset($_SESSION['username'])) echo $_SESSION['username']; ?></p>
        </div>
       
      </form>
</ul>
</div>
</div>
</div>


<div class="row">
<div class="col-sm-12 col-xs-12">
        <div class="panel panel-default">
            <div class="panel-heading"><img src="img/deep.png" alt="deep Logo"></div>
            <article style="font-family: Arial, Helvetica, sans-serif;padding-left: 60px;
    padding-right: 60px;text-align: left;">
   
               <p>Deep tissue massage is very similar to Swedish massage using quite a lot of the same strokes but the movement is very different. The strokes are much slower and deeper usually focusing on a specific problem for example chronic tights muscles, limited mobility and many more. On areas of tension and stress found in the deeper layers of the muscles tissues, tendons and fascia. Aiding in the realignment of these tissues.</p>
<p>This type of treatment is fantastic for people who suffer with chronic pains, aches, niggles or damage sustained during a injury where adhesions (bands of fibrous painful tissue ) have occurred. Often leading to blocking circulation causing pain, reducing range of movement and leading to inflammation.</p>
<p>Deep tissue massage helps break down these adhesions reducing your pain and optimising your well–being emotionally and physically.</p>
<p><span style="color: #000000;"><strong>Does deep tissue massage hurt?</strong></span></p>
<p>Some discomfort and pain can be experienced, in certain areas where there is underlying issues.</p>
<p>It is essential to tell us if discomfort or pain is beyond your comfort range. The more comfortable and relaxed the client is, the further I can go deeper into the muscles and achieve greater results.</p>
            </article>
   <a href="booking.php" class="btn btn-primary" role="button">Book Session</a>
      <br><br>
 </div>
 </div>
</div>
    

        
        <div class="panel panel-default">
  <div class="panel-body">
<footer>Copyright&copy; Martin Gibbons 2016</footer>
</div>
</div>      
           
            


  


</body>