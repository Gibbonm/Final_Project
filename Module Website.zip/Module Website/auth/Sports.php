<?php include_once 'resource/session.php' ?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Bootstrap -->
     
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css?family=Righteous" rel="stylesheet">
     <link href="css/custom.css" rel="stylesheet">


     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
     <script src="js/cart.js"></script>





    <title>Sports Injuries</title>
</head>
<body>
<br>
<div class="container">

<div class="jumbotron"><h1><img src="img/background.png" alt="therapy">&nbsp;&nbsp;&nbsp;Galway Physical Therapy</h1>
</div>

    <div>
<div class="panel panel-default">
    <div class="panel-body" id="nav1">
    
    <ul class="nav nav-pills">
  <li role="presentation" ><a href="index.php">Home</a></li>
  <li role="presentation"><a href="about.php">About</a></li>
  <li role="presentation"><a href="feedback.php">Contact</a></li>
   <li role="presentation" id="logout"><a href="logout.php">Logout</a></li>
   <li role="presentation"><a href="forgot_password.php">Reset Password</a></li>



<form class="navbar-form navbar-right" >
        <div class="form-group">
          <p>You are logged in as <?php if(isset($_SESSION['username'])) echo $_SESSION['username']; ?></p>
        </div>
       
      </form>
</ul>
</div>
</div>
</div>


<div class="row">
<div class="col-sm-12 col-xs-12">
        <div class="panel panel-default">
            <div class="panel-heading"><img src="img/sports.png" alt="sports Logo"></div>
            <h2>Sports Injuries</h2>
            <article style="font-family: Arial, Helvetica, sans-serif;padding-left: 60px;
    padding-right: 60px;text-align: left;">
   
          <p style="text-align: left;">Sports Therapy involves assessment, treatment, rehabilitation and prevention of injuries or day to day aches and niggles.  Such issues can arise through sports, work or daily activities. Sports Therapy is an effective manual therapy, using soft tissue massage, stretching techniques and taping and strapping, along with aftercare advice to maintain recovery and prevent recurrence.</p>
<p>Sports massage should be used as a prevention to keep the body healthy from aches and pains from overuse and stress build up in the body.  Sports Massage can break down the tension and scar tissue quickly and effectively to enhance muscles performance.  It can be used in conjunction with other therapies for specific injuries.</p>
<p>Sports massage is divided into three categories pre-event, post-event and injury treatment.</p>
<h4><strong>Pre-Event Massage: </strong></h4>
<p>A specific treatment using light stimulating strokes combined with flexibility and mobility work to prepare the body for a particular event.  It is short in duration and is carried out immediately before an event (30mins-24hr). It is tailored to focus on the main muscles that will be used during the chosen activity to warm their muscles and to prepare their bodies for performance.  The aim of this treatment is to increase circulation, enhance endurance, stimulate the body, boost performance and reduce the risk of injury.</p>
<p><strong><em>Pre-event massage does not replace your warm up prior to performance.</em></strong></p>
<h4><strong>Post –Event Massage</strong>:</h4>
<p>An essential in aiding in an athlete’s recovery, during an event an athlete often pushes further than in a training session. Post-event massage is essential to a pain-free recovery. During the process, the athlete is first assessed for potential injuries and by working into the muscles relieve pain, improves muscle tone, improve circulation and restore flexibility. To reduce the risk of D.O.M.S (Delayed onset of Muscle Soreness), so the athlete can return to training the next day.</p>
<p><strong>Contact us and experience the benefits of a sports therapy program designed specifically for you.</strong></p>

            </article>
     <a href="booking.php" class="btn btn-primary" role="button">Book Session</a>
      <br><br>
 </div>
 </div>
</div>
    

        
        <div class="panel panel-default">
  <div class="panel-body">
<footer>Copyright&copy; Martin Gibbons 2016</footer>
</div>
</div>      
           
            


  


</body>