<?php
//add our database connection script
//include_once 'resource/Database.php';
include_once 'resource/utilities.php';
include_once 'resource/session.php';



        var $vdgd = 'quantity'+i
        $qty = $_COOKIE['quantity'+i];
        $item = $_COOKIE['item1'];

        echo 'XXXXXXXX';
        echo $qty;
        //$item = $_GET['item_name1'];
        //$amt = $_GET['amount_1'];
        //$subtotal = $_GET['amount_1'];
        //$total = $_GET['amount_1'];
        //@mysqli_query ($dbc, $q)
            //create SQL insert statement
        $db = mysqli_connect('localhost', 'root', '', 'register');
        $q = "INSERT INTO cart (Quantity, item_name) VALUES ('$qty','$item')";     
        $r = @mysqli_query ($db, $q); // Run the query.
  
        //echo $db;
        //echo mysqli_error($db);
//echo '<p>' . mysqli_error($db) . '<br /><br />Query: ' . $q . '</p>';            


?>