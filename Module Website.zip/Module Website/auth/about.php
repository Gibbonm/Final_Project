<?php include_once 'resource/session.php' ?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Bootstrap -->
     
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css?family=Righteous" rel="stylesheet">
     <link href="css/custom.css" rel="stylesheet">


     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>





    <title>About</title>
</head>
<body>
<br>
<div class="container">

<div class="jumbotron"><h1><img src="img/background.png" alt="therapy">&nbsp;&nbsp;&nbsp;Galway Physical Therapy</h1>
</div>

    <div>
<div class="panel panel-default">
    <div class="panel-body" id="nav1">
    
    <ul class="nav nav-pills">
  <li role="presentation" ><a href="index.php">Home</a></li>
  <li role="presentation" class="active"><a href="#">About</a></li>
  <li role="presentation"><a href="feedback.php">Contact</a></li>
   <li role="presentation" id="logout"><a href="logout.php">Logout</a></li>
   <li role="presentation"><a href="forgot_password.php">Reset Password</a></li>



<form class="navbar-form navbar-right" >
        <div class="form-group">
          <p>You are logged in as <?php if(isset($_SESSION['username'])) echo $_SESSION['username']; ?></p>
        </div>
       
      </form>
</ul>
</div>
</div>
</div>


<div class="row">
<div class="col-sm-12 col-xs-12">
        <div class="panel panel-default">
            <div class="panel-heading"><img src="img/what.png" alt="what Logo"></div>
            <article style="font-family: Arial, Helvetica, sans-serif;padding-left: 60px;
    padding-right: 60px;text-align: center;">
   
                <h2>Neuromuscular Physical Therapist</h2><p>I am a registered Neuromuscular Physical Therapist specialising in muscloskeletal conditions and I&#8217;ve been working in this field since 2007 gaining a vast array of experience from different clinics, gyms and sports clubs in Cavan and Galway. In 2012, I established my own clinic in Oranmore, Galway. I continuously update my skills and knowledge in physical therapy and endeavour to utilise the latest techniques to achieve the best possible results for my clients. I also work in the medical field as an Emergency Medical Technician at popular events including this year’s Run-A-Muck challenge and Galway Races.</p>
                <p>Offering an array of services including Neuromuscular Physical Therapy, Sports Therapy Massage, Dry Needling and Holistic massage. I treats injuries for every individual who is concerned about their health and well-being, whether it is chronic or acute pain and can help prevent it with the correct guidance and information.</p>
                <p>Each treatment is tailored to meet the specific individuals needs of my clients to improve their mobility and relieve pain, so they can enjoy a better quality of day to day life and achieve their goals.</p>
                <p><strong><span style="font-size: 10pt; font-family: Verdana, sans-serif;">If you are unsure of the most appropriate treatment to suit your needs, please contact me for more advice and information relating specifically to your situation.</span></strong></p>
   </article>
 </div>
 </div>
</div>
    

        
        <div class="panel panel-default">
  <div class="panel-body">
<footer>Copyright&copy; Martin Gibbons 2016</footer>
</div>
</div>      
           
            


  


</body>