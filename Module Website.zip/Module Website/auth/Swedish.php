<?php include_once 'resource/session.php' ?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Bootstrap -->
     
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css?family=Righteous" rel="stylesheet">
     <link href="css/custom.css" rel="stylesheet">


     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/cart.js"></script>





    <title>Swedish Massage</title>
</head>
<body>
<br>
<div class="container">

<div class="jumbotron"><h1><img src="img/background.png" alt="therapy">&nbsp;&nbsp;&nbsp;Galway Physical Therapy</h1>
</div>

    <div>
<div class="panel panel-default">
    <div class="panel-body" id="nav1">
    
    <ul class="nav nav-pills">
  <li role="presentation" ><a href="index.php">Home</a></li>
  <li role="presentation"><a href="about">About</a></li>
  <li role="presentation"><a href="feedback.php">Contact</a></li>
   <li role="presentation" id="logout"><a href="logout.php">Logout</a></li>
   <li role="presentation"><a href="forgot_password.php">Reset Password</a></li>



<form class="navbar-form navbar-right" >
        <div class="form-group">
          <p>You are logged in as <?php if(isset($_SESSION['username'])) echo $_SESSION['username']; ?></p>
        </div>
       
      </form>
</ul>
</div>
</div>
</div>


<div class="row">
<div class="col-sm-12 col-xs-12">
        <div class="panel panel-default">
            <div class="panel-heading"><img src="img/swedish.png" alt="swedish Logo"></div>
            <h2>Swedish/Holistic Massage</h2>
            <article style="font-family: Arial, Helvetica, sans-serif;padding-left: 60px;
    padding-right: 60px;text-align: left;">
   <p>Swedish/Holistic massage is the most common form of therapeutic massages in the world. Swedish massage techniques are designed to sooth and relax the entire body this is achieved by using long vigorous strokes in the direction towards the heart. Depending on your needs and comfort range the pressure will vary to deep or gently strokes.  The techniques used in Swedish massage manipulate the muscles to relax, gradually braking down “knots”.</p>
<p>Swedish/Holistic massage is the most common form of therapeutic massages. With its vigorous strokes and deep pressure, it manipulates the muscles to relax and stimulates the whole body to give the body “balance”.</p>
<p><strong>Benefits</strong></p>
<ul>
<li>Improves Circulation</li>
<li>Improves supply of oxygen and nutrients to the muscles</li>
<li>Improves skin tone, colour and elasticity</li>
<li>Eliminates toxins from the body</li>
<li>Relaxes the body and mind thus reducing stress and anxiety</li>
<li>Relieves muscle fatigue and soreness</li>
<li>Relieves sore, stiff joints</li>
<li>Promotes general relaxation</li>
<li>Stimulates the immune system and aid digestion</li>
</ul>
<p><strong>Contact me to discuss your symptoms and the benefits of massage.</strong></p>
           


            </article>
   <a href="booking.php" class="btn btn-primary" role="button">Book Session</a>
      <br><br>
 </div>
 </div>
</div>
    

        
        <div class="panel panel-default">
  <div class="panel-body">
<footer>Copyright&copy; Martin Gibbons 2016</footer>
</div>
</div>      
           
            


  


</body>