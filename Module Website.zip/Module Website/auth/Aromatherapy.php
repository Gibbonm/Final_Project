<?php include_once 'resource/session.php' ?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Bootstrap -->
     
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css?family=Righteous" rel="stylesheet">
     <link href="css/custom.css" rel="stylesheet">


     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/cart.js"></script>





    <title>Aromatherapy</title>
</head>
<body>
<br>
<div class="container">

<div class="jumbotron"><h1><img src="img/background.png" alt="therapy">&nbsp;&nbsp;&nbsp;Galway Physical Therapy</h1>
</div>

    <div>
<div class="panel panel-default">
    <div class="panel-body" id="nav1">
    
    <ul class="nav nav-pills">
  <li role="presentation" ><a href="index.php">Home</a></li>
  <li role="presentation"><a href="anout.php">About</a></li>
  <li role="presentation"><a href="feedback.php">Contact</a></li>
   <li role="presentation"><a href="logout.php">Logout</a></li>
   <li role="presentation"><a href="forgot_password.php">Reset Password</a></li>



<form class="navbar-form navbar-right" >
        <div class="form-group">
          <p>You are logged in as <?php if(isset($_SESSION['username'])) echo $_SESSION['username']; ?></p>
        </div>
       
      </form>
</ul>
</div>
</div>
</div>


<div class="row">
<div class="col-sm-12 col-xs-12">
        <div class="panel panel-default">
            <div class="panel-heading"><img src="img/Aromatherapy.png" alt="Aromatherapy Logo"></div>
            <h2>Aromatherapy</h2>
            <article style="font-family: Arial, Helvetica, sans-serif;padding-left: 60px;
    padding-right: 60px;text-align: left;">
   
        
  <p>Aromatherapy is the practice of using natural essential oils which have been extracted from roots, leaves, seeds, or blossoms from plants in a holistic therapy that improves physical and emotional well-being. As the name suggests, Aromatherapy is based on inhalation, which stimulates brain function. It can also be absorbed through the skin by massage which later enters into the bloodstream, stimulating the body to relax and heal. Each oil has its own properties, affecting the body in three key processes: pharmacologically, physiologically and psychologically.</p>
<p><strong>Benefits: </strong></p>
<ul>
<li>Uplifting: helps positive thinking and emotions</li>
<li>Antidepressant and relaxant</li>
<li>Relieves sore muscles and pain</li>
<li>Improves skin tone, colour and elasticity</li>
<li>Lowers blood pressure</li>
<li>Improves Circulation</li>
<li>Stimulates the immune system and aids digestion</li>
<li>Encourages sleep</li>
<li>Improves energy levels</li>
</ul>

            </article>
  
   <a href="booking.php" class="btn btn-primary" role="button">Book Session</a>
   <br><br>
 </div>
 </div>
</div>
    

        
        <div class="panel panel-default">
  <div class="panel-body">
<footer>Copyright&copy; Martin Gibbons 2016</footer>
</div>
</div>      
           
            


  


</body>