<?php
//add our database connection script
include_once 'resource/Database.php';
include_once 'resource/utilities.php';
include_once 'resource/session.php';

//process the form
if(isset($_POST['signupBtn'])){
    //initialize an array to store any error message from the form
    $form_errors = array();

    //Form validation
    $required_fields = array('Quantity', 'item_name', 'cost');

    //call the function to check empty field and merge the return data into form_error array
    $form_errors = array_merge($form_errors, check_empty_fields($required_fields));

    //Fields that requires checking for minimum length
    $fields_to_check_length = array('Quantity' => 1, 'item_name' => 1);

    //call the function to check minimum required length and merge the return data into form_error array
    $form_errors = array_merge($form_errors, check_min_length($fields_to_check_length));

    //email validation / merge the return data into form_error array
    $form_errors = array_merge($form_errors, check_email($_POST));

    //check if error array is empty, if yes process form data and insert record
    if(empty($form_errors)){
        //collect form data and store in variables
        $qty = $_POST['quantity1'];
        $item = $_POST['item_name1'];
        $amt = $_POST['amount_1'];
        $subtotal = $_POST['amount_1]'];
        $total = $_POST['amount_1]'];
    # $message = $_POST['total'];

        //hashing the password
       
        try{

            //create SQL insert statement
            $sqlInsert = "INSERT INTO cart (Quantity, item_name, cost, subtotal,total)
              VALUES ($qty, $item, $amt, $subtotal, $total)";

            //use PDO prepared to sanitize data
            $statement = $db->prepare($sqlInsert);

            //add the data into the database
    $statement->execute(array(':Quantity' => $qty, ':item_name' => $item, ':cost' => $amt,':subtotal' => $subtotal,':total' => $total,));

            //check if one new row was created
            if($statement->rowCount() == 1){
                $result = "<p style='padding:20px; border: 1px solid gray; color: green;'> Message Sent</p>";
            }
        }catch (PDOException $ex){
            $result = "<p style='padding:20px; border: 1px solid gray; color: red;'> An error occurred: ".$ex->getMessage()."</p>";
        }
    }
    else{
        if(count($form_errors) == 1){
            $result = "<p style='color: red;'> There was 1 error in the form<br>";
        }else{
            $result = "<p style='color: red;'> There were " .count($form_errors). " errors in the form <br>";
        }
    }

}

?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="css/custom.css" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css?family=Righteous" rel="stylesheet">



     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
     <script src="js/cart2.js"></script>
     <script src="js/jquery.creditCardValidator.js"></script>
    <script src="js/cc_validator.js"></script>
    <title>Checkout</title>
</head>
<body>
<br>
<div class="container">

<div class="jumbotron"><h1><img src="img/background.png" alt="therapy">&nbsp;&nbsp;&nbsp;Galway Physical Therapy</h1>
</div>

  <div>
<div class="panel panel-default">
    <div class="panel-body" id="nav1">
    
    <ul class="nav nav-pills">
  <li role="presentation" ><a href="index.php">Home</a></li>
  <li role="presentation"><a href="about.php">About</a></li>
  <li role="presentation" ><a href="feedback.php">Contact</a></li>
   <li role="presentation" id="logout"><a href="logout.php">Logout</a></li>
   <li role="presentation"><a href="forgot_password.php">Reset Password</a></li>



<form class="navbar-form navbar-right" >
        <div class="form-group">
          <p>You are logged in as <?php if(isset($_SESSION['username'])) echo $_SESSION['username']; ?></p>
        </div>
       
      </form>
</ul>
</div>
</div>
</div>
 <!-- 
<div class="row">
    <div class="col-sm-12 col-xs-12">
        <div class="panel panel-default">
            <?php if(isset($result)) echo $result; ?>
            <?php if(!empty($form_errors)) echo show_errors($form_errors); ?>
            <br>
            <h3>Contact Form</h3>
            <br>
            <form method="post" action="">
          
            <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email:<input type="text" value="" name="email"></p>
             <p>Username:<input type="text" value="" name="username"></p>
           <p>message:<textarea  type="text" value="" name="message"></textarea></p>
           <p><input class="btn btn-primary" type="submit" name="signupBtn" value="Send Message"></p>
          
            </form>
            <p><a href="index.php">Back</a> </p>
                <div class="panel-body">
                       

</div>
 </div>
 </div>
 </div>-->


        <div class="panel panel-default">
        <?php if(isset($result)) echo $result; ?>
            <?php if(!empty($form_errors)) echo show_errors($form_errors); ?>
           <!--https://www.paypal.com/cgi-bin/webscr-->
        <h1>Shopping Checkout</h1>
        <p>Enter credit card number in field below to validate it</p><br>
    <input id="cc_number" value=""><br> <!-- value has a valid text credit card number 5105105105105100-->
    <p id="message"></p><br>
    <button type="button" class="confirm">Confirm</button>



        <!--https://www.paypal.com/cgi-bin/webscr  -->
        <form action="" method="post">
            <input type="hidden" name="cmd" value="_cart">
            <input type="hidden" name="upload" value="1">
            <input type="hidden" name="business" value="martin.gmit@gmail.com">
            <table class="table table-hover">
                <thead class="thead-inverse">
                    <tr>
                        <th>Qty</th>
                        <th>Item Name</th>
                        <th>Cost</th>
                        <th class="text-xs-right">Subtotal</th>
                    </tr>
                </thead>
                <tbody id="output"> </tbody>
            </table>
            <input  type="submit" name="signupBtn" class="btn btn-primary" value="Checkout "> <a href="booking.php" class="btn btn-success">Continue Shopping</a> </form>
            <br><br>
    
 </div>


   <div class="panel panel-default">
  <div class="panel-body">
<footer>Copyright&copy; Martin Gibbons 2016</footer>
</div>
</div>



</body>
</html>