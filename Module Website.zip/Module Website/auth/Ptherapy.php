<?php include_once 'resource/session.php' ?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Bootstrap -->
     
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css?family=Righteous" rel="stylesheet">
     <link href="css/custom.css" rel="stylesheet">


     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/cart.js"></script>






    <title>Physical Therapy</title>
</head>
<body>
<br>
<div class="container">

<div class="jumbotron"><h1><img src="img/background.png" alt="therapy">&nbsp;&nbsp;&nbsp;Galway Physical Therapy</h1>
</div>

    <div>
<div class="panel panel-default">
    <div class="panel-body" id="nav1">
    
    <ul class="nav nav-pills">
  <li role="presentation" ><a href="index.php">Home</a></li>
  <li role="presentation"><a href="about.php">About</a></li>
  <li role="presentation"><a href="feedback.php">Contact</a></li>
   <li role="presentation"><a href="logout.php">Logout</a></li>
   <li role="presentation"><a href="forgot_password.php">Reset Password</a></li>



<form class="navbar-form navbar-right" >
        <div class="form-group">
          <p>You are logged in as <?php if(isset($_SESSION['username'])) echo $_SESSION['username']; ?></p>
        </div>
       
      </form>
</ul>
</div>
</div>
</div>


<div class="row">
<div class="col-sm-12 col-xs-12">
        <div class="panel panel-default">
            <div class="panel-heading"><img src="img/about.png" alt="physical therapy Logo"></div>
            <h2>Neuromuscular Physical Therapy</h2>
            <article style="font-family: Arial, Helvetica, sans-serif;padding-left: 60px;
    padding-right: 60px;text-align: left;">
   <p style="text-align: left;">Neuromuscular Physical Therapy (NMT) is a hands on therapy that incorporates specific soft tissue manipulations techniques and equipment to help aid and improve a patient’s physical health by working on muscles, tendons and connective tissue. Regardless, if your pain occurred through sports injuries, repetitive strain at work or poor posture over the years, physical therapy can reduce your pain, promote physical and emotion well-being and increase joints, muscle function and bio-mechanics (movement) in the musculoskeletal system by bringing balance back to the body.</p>
<h4><span style="color: #000000;"><strong>How Does Neuromuscular Physical Therapy Work?</strong></span></h4>
<p>NMT involves the treatment process of healing, through a variety of techniques such as Sports Massage  combined Neuromuscular techniques like Trigger Point Therapy, Myofascial Release, Soft Tissue Release, Muscular Energy Techniques, Positional Release on the soft tissue injuries, restoring them to optimal health. Through further home care advice, physical therapy can eliminate pain and prevent the injury occurring again in the future, restoring homeostasis to the body.</p>
<h4><span style="color: #000000;"><strong>What Does Each Treatment Involve?</strong></span></h4>
<p>With every treatment regardless acute or chronic injuries  a confidential one-to-one consultation is carried out gathering as much information as possible concerning health issues, diet and of course old or current injuries to identify exactly what is going on with the body.  From there, a postural assessment is carried out allowing the body tell us what’s going on and where it’s holding all the tension and stress, as our body as a way of  compensating and adoption to make up for overused muscles. Followed by a variety of Orthopaedic Sport Massage tests:  range of motion, joint assessment, nerve entrapment, muscle shortness so that we can tailor the treatment to suit the individual needs of the Client.</p>
<br><br>
   
               </article>
   

   <a href="booking.php" class="btn btn-primary" role="button">Book Session</a>
   <br><br>
    
   
        
   
 </div>
 </div>
</div>
    

        
        <div class="panel panel-default">
  <div class="panel-body">
<footer>Copyright&copy; Martin Gibbons 2016</footer>
</div>
</div>      
           
            


  


</body>