<?php include_once 'resource/session.php' ?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="css/custom.css" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css?family=Righteous" rel="stylesheet">


     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>





    <title>Homepage</title>
</head>
<body>
<br>
<div class="container">

<div class="jumbotron"><h1><img src="img/background.png" alt="therapy">&nbsp;&nbsp;&nbsp;Galway Physical Therapy</h1>
</div>







<?php if(!isset($_SESSION['username'])): ?>
<div class="row">
 	<div class="col-sm-6 col-xs-12">
		<div class="panel panel-default">
			<div class="panel-heading"><a href="login.php"><img src="img/existing.png" alt="shoe Logo"></a><br>Already a Client</div>
				<div class="panel-body">
						<a href="login.php" class="btn btn-primary" role="button">Sign in</a>

</div>
 </div>
 </div>
 
  


 	<div class="col-sm-6 col-xs-12">
		<div class="panel panel-default">
			<div class="panel-heading"><a href="signup.php"><img src="img/hard.png" alt="apparel Logo"></a><br>New Client</div>
				<div class="panel-body">
						 <a href="signup.php" class="btn btn-primary" role="button">Sign up</a>
</div>
 </div>
 </div>
  </div>

<?php else: ?>
	<div>
<div class="panel panel-default">
	<div class="panel-body" id="nav1">
	
	<ul class="nav nav-pills">
  <li role="presentation" ><a href="index.php">Home</a></li>
  <li role="presentation"><a href="about.php">About</a></li>
  <li role="presentation"><a href="feedback.php">Contact</a></li>
   <li role="presentation" id="logout"><a href="logout.php">Logout</a></li>
   <li role="presentation"><a href="forgot_password.php">Reset Password</a></li>



<form class="navbar-form navbar-right" >
        <div class="form-group">
          <p>You are logged in as <?php if(isset($_SESSION['username'])) echo $_SESSION['username']; ?></p>
        </div>
       
      </form>
</ul>
</div>
</div>
</div>

 <div class="row">
 	<div class="col-sm-4 col-xs-12">
		<div class="panel panel-default">
			<div class="panel-heading"><a href="Ptherapy.php"><img src="img/about.png" alt="about Logo"></a><br>Physical Therapy</div>
				<div class="panel-body">
						<a href="Ptherapy.php" class="btn btn-primary" role="button">Read More</a>

</div>
 </div>
 </div>
 
  


 	<div class="col-sm-4 col-xs-12">
		<div class="panel panel-default">
			<div class="panel-heading"><a href="needling.php"><img src="img/needling.png" alt="apparel Logo"></a><br>Dry Needling</div>
				<div class="panel-body">
						 <a href="needling.php" class="btn btn-primary" role="button">Read More</a>
</div>
 </div>
 </div>
  
  <div class="col-sm-4 col-xs-12">
    <div class="panel panel-default">
      <div class="panel-heading"><a href="Sports.php"><img src="img/Sports.png" alt="apparel Logo"></a><br>Sports Injuries</div>
        <div class="panel-body">
             <a href="Sports.php" class="btn btn-primary" role="button">Read More</a>
</div>
 </div>
 </div>

<div class="col-sm-4 col-xs-12">
    <div class="panel panel-default">
      <div class="panel-heading"><a href="Deep.php"><img src="img/Deep.png" alt="apparel Logo"></a><br>Deep Tissue Massage</div>
        <div class="panel-body">
             <a href="Deep.php" class="btn btn-primary" role="button">Read More</a>
</div>
 </div>
 </div>

<div class="col-sm-4 col-xs-12">
    <div class="panel panel-default">
      <div class="panel-heading"><a href="Swedish.php"><img src="img/Swedish.png" alt="apparel Logo"></a><br>Swedish Massage</div>
        <div class="panel-body">
             <a href="Swedish.php" class="btn btn-primary" role="button">Read More</a>
</div>
 </div>
 </div>

 <div class="col-sm-4 col-xs-12">
    <div class="panel panel-default">
      <div class="panel-heading"><a href="Aromatherapy.php"><img src="img/Aromatherapy.png" alt="apparel Logo"></a><br>Aromatherapy</div>
        <div class="panel-body">
             <a href="Aromatherapy.php" class="btn btn-primary" role="button">Read More</a>
</div>
 </div>
 </div>

</div>




<?php endif ?>


 	<div class="panel panel-default">
  <div class="panel-body">
<footer>Copyright&copy; Martin Gibbons 2016</footer>
</div>
</div>


 
</body>
</html>