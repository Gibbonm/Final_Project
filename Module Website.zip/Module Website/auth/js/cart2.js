 var shopcart = [];
        $(document).ready(function () {

            $("#logout").click(function() {

                sessionStorage.clear();
        console.log("session clear");
     });




            outputCart();
            $('#output').on('change keyup', '.dynqua', function () {
                var iteminfo = $(this.dataset)[0];
                var itemincart = false;
                console.log(shopcart);
                var qty = $(this).val();
                if (qty < 0) {
                    qty = 0;
                    $(this).val(0);
                }
                $.each(shopcart, function (index, value) {
                    if (value.id == iteminfo.id) {
                        shopcart[index].qty = qty;
                        itemincart = true;
                    }
                })
                sessionStorage["sca"] = JSON.stringify(shopcart);
                outputCart();
            })

            function outputCart() {
                if (sessionStorage["sca"] != null) {
                    shopcart = JSON.parse(sessionStorage["sca"].toString());
                }
                console.log(sessionStorage["sca"]);
                console.log(shopcart.length);
                var holderHTML = '';
                var total = 0;
                var itemCnt = 0;
                $.each(shopcart, function (index, value) {
                    var stotal = value.qty * value.price;
                    var a = (index + 1);
                    //alert(a);
                    total += stotal;
                    itemCnt += parseInt(value.qty);
                    holderHTML += '<tr><td><input size="5"  type="number" class="dynqua" name="quantity' + a + '" value="' + value.qty + '" data-id="' + value.id + '"></td><td><input type="hidden" name="item_name' + a + '" value="' + value.name + ' ' + value.s + '">' + value.name + '(' + value.s + ')</td><td><input type="hidden" name="cost' + a + '" value="' + formatMoney(value.price) + '"> €' + formatMoney(value.price) + ' </td><td class="text-xs-right"> ' + formatMoney(stotal) + '</td></tr>';
                    var price =50;
//formatMoney(value.price)
                    document.cookie="quantity"+a+"="+value.qty;
                    document.cookie="item"+a+"="+value.name;
                    document.cookie="price"+a+"="+price;
                    document.cookie="stotal="+formatMoney(stotal);
                    document.cookie="total="+formatMoney(total);
                    document.cookie="cart="+shopcart.length;
                    //alert(document.cookie);
                    console.log(price);
                    console.log(value.name);
                    console.log(formatMoney(stotal));
                    console.log(formatMoney(total));
                })

                holderHTML += '<tr><td colspan="3" class="text-xs-right">Total</td><td class="text-xs-right" name="total">€' + formatMoney(total) + '</td></tr>';
                $('#output').html(holderHTML);
            }

            function formatMoney(n) {
                return (n / 100).toFixed(2);
            }
        })
  

