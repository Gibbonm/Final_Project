<?php include_once 'resource/session.php' ?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Bootstrap -->
     
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css?family=Righteous" rel="stylesheet">
     <link href="css/custom.css" rel="stylesheet">


     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/cart.js"></script>





    <title>Dry Needling</title>
</head>
<body>
<br>
<div class="container">

<div class="jumbotron"><h1><img src="img/background.png" alt="therapy">&nbsp;&nbsp;&nbsp;Galway Physical Therapy</h1>
</div>

    <div>
<div class="panel panel-default">
    <div class="panel-body" id="nav1">
    
    <ul class="nav nav-pills">
  <li role="presentation" ><a href="index.php">Home</a></li>
  <li role="presentation" ><a href="about.php">About</a></li>
  <li role="presentation"><a href="feedback.php">Contact</a></li>
   <li role="presentation" id="logout"><a href="logout.php">Logout</a></li>
   <li role="presentation"><a href="forgot_password.php">Reset Password</a></li>



<form class="navbar-form navbar-right" >
        <div class="form-group">
          <p>You are logged in as <?php if(isset($_SESSION['username'])) echo $_SESSION['username']; ?></p>
        </div>
       
      </form>
</ul>
</div>
</div>
</div>


<div class="row">
<div class="col-sm-12 col-xs-12">
        <div class="panel panel-default">
            <div class="panel-heading"><img src="img/needling.png" alt="needling Logo"></div>
            <h2>Dry Needling</h2>
            <article style="font-family: Arial, Helvetica, sans-serif;padding-left: 60px;
    padding-right: 60px;text-align: left;">
   
  <p>Dry needling is a safe procedure using acupuncture needles inserted into the muscle directly at a myofascial trigger point. A myofascial trigger point consists of multiple contractions within a muscle causing a tender point inside the taut bands of muscle also known as a knot. They occur in overworked or traumatised muscles and contain noxious chemical. Which later develops into pain in that area or referral pain somewhere else in the body.</p>
<p>Inserting a very fine needle into the point and producing local twitch responses (spinal cord reflex) which results in the release of the myofascial trigger point along with the chemicals it contains, allowing biochemical changes to occur which assist in pain relief.</p>
<p>&nbsp;</p>
<p><strong><span style="color: #000000;">What is the difference between Myofascial Trigger Point Dry Needling and Acupuncture?<br />
</span></strong>Acupuncture is a traditional Chinese medicine that works on the understanding of energy flow, Qi, or Chi in the body. The approach that Acupuncture takes is that, if there is an energy blockage in the energy flow, it will create various health problems e.g. infections. The idea behind Acupuncture is to attempt to clear these blockages, allowing for balance in the body.</p>
<p>Myofascial Trigger Point Dry Needling, deals with the neuromuscular approach dealing directly with the muscle, relieving pain by inserting filament needles directly into the Myofascial trigger points. This causes a local twitch response, which results in the releasing of the myofascial trigger point along with the chemicals it contains, reduces pain, improving circulation and improve muscle function, strength and flexibility</p>
<p>Myofascial Trigger Point Dry Needling is a scientifically proven method of pain relief.</p>
<p>&nbsp;</p>
<p><strong>What are the side effects of Myofascial Trigger Point Dry Needling?</strong><br />
The most common side effect after a dry needling session is usually muscle soreness, symptoms subside within 24 to 48 hours.</p>
<p><strong>What are the side effects of Myofascial Trigger Point Dry Needling?</strong><br />
The most common side effects after a dry needling session is usually muscle cramping and soreness. These symptoms usually subside within 24 to 48 hours.</p>
<p><strong>What injuries can Myofascial Trigger Point Dry Needling treat?</strong><br />
Myofascial Trigger Point Dry Needling can fix a variety of musculoskeletal problems. There are many conditions which can be treated:</p>              
    

            </article>
     <a href="booking.php" class="btn btn-primary" role="button">Book Session</a>
      <br><br>
 </div>
 </div>
</div>
    

        
        <div class="panel panel-default">
  <div class="panel-body">
<footer>Copyright&copy; Martin Gibbons 2016</footer>
</div>
</div>      
           
            


  


</body>