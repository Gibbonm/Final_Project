<?php
//add our database connection script
include_once 'resource/Database.php';
include_once 'resource/utilities.php';
include_once 'resource/session.php';

if(isset($_POST['signupBtn'])){

$cart = $_COOKIE['cart'];
for ($x = 1; $x <= $cart; $x++) {
    
        $i = 1;
        $qty = $_COOKIE['quantity'.$x];
        $item = $_COOKIE['item'.$x];
        $price = $_COOKIE['price'.$x];
        $stotal = $_COOKIE['stotal'];
        $total = $_COOKIE['total'];
        $user  =$_SESSION['username'];
        echo $user;
        echo $cart;
        echo $qty;
       
        $db = mysqli_connect('localhost', 'root', '', 'register');
        $q = "INSERT INTO cart (Quantity, item_name, cost, subtotal,total) VALUES ('$qty','$item','$price','$stotal','$total')";     
        $r = @mysqli_query ($db, $q); // Run the query.
    }
  }
        //echo $db;
        //echo mysqli_error($db);
//echo '<p>' . mysqli_error($db) . '<br /><br />Query: ' . $q . '</p>';            


?>
            



<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="css/custom.css" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css?family=Righteous" rel="stylesheet">



     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
     <script src="js/cart2.js"></script>
     <script src="js/jquery.creditCardValidator.js"></script>
    <script src="js/cc_validator.js"></script>
    <title>Checkout</title>
</head>
<body>
<br>
<div class="container">

<div class="jumbotron"><h1><img src="img/background.png" alt="therapy">&nbsp;&nbsp;&nbsp;Galway Physical Therapy</h1>
</div>

  <div>
<div class="panel panel-default">
    <div class="panel-body" id="nav1">
    
    <ul class="nav nav-pills">
  <li role="presentation" ><a href="index.php">Home</a></li>
  <li role="presentation"><a href="about.php">About</a></li>
  <li role="presentation" ><a href="feedback.php">Contact</a></li>
   <li role="presentation" id="logout"><a href="logout.php">Logout</a></li>
   <li role="presentation"><a href="forgot_password.php">Reset Password</a></li>



<form class="navbar-form navbar-right" >
        <div class="form-group">
          <p>You are logged in as <?php if(isset($_SESSION['username'])) echo $_SESSION['username']; ?></p>
        </div>
       
      </form>
</ul>
</div>
</div>
</div>
 <!-- 
<div class="row">
    <div class="col-sm-12 col-xs-12">
        <div class="panel panel-default">
            <?php if(isset($result)) echo $result; ?>
            <?php if(!empty($form_errors)) echo show_errors($form_errors); ?>
            <br>
            <h3>Contact Form</h3>
            <br>
            <form method="post" action="">
          
            <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email:<input type="text" value="" name="email"></p>
             <p>Username:<input type="text" value="" name="username"></p>
           <p>message:<textarea  type="text" value="" name="message"></textarea></p>
           <p><input class="btn btn-primary" type="submit" name="signupBtn" value="Send Message"></p>
          
            </form>
            <p><a href="index.php">Back</a> </p>
                <div class="panel-body">
                       

</div>
 </div>
 </div>
 </div>-->


        <div class="panel panel-default">
        <?php if(isset($result)) echo $result; ?>
            <?php if(!empty($form_errors)) echo show_errors($form_errors); ?>
           <!--https://www.paypal.com/cgi-bin/webscr-->
        <h1>Shopping Checkout</h1>
        <p>Enter credit card number in field below to validate it</p><br>
    <input id="cc_number" value=""><br> <!-- value has a valid text credit card number 5105105105105100-->
    <p id="message"></p><br>
    <button type="button" class="confirm">Confirm</button>



        <!--https://www.paypal.com/cgi-bin/webscr kevin.php -->
        <form action="" method="post">
            <input type="hidden" name="cmd" value="_cart">
            <input type="hidden" name="upload" value="1">
            <input type="hidden" name="business" value="martin.gmit@gmail.com">
            <table class="table table-hover">
                <thead class="thead-inverse">
                    <tr>
                        <th>Qty</th>
                        <th>Item Name</th>
                        <th>Cost</th>
                        <th class="text-xs-right">Subtotal</th>
                    </tr>
                </thead>
                <tbody id="output"> </tbody>
            </table>
            <input  type="submit" name="signupBtn" class="btn btn-primary" value="Checkout "> <a href="booking.php" class="btn btn-success">Continue Shopping</a> </form>
            <br><br>
    
 </div>


   <div class="panel panel-default">
  <div class="panel-body">
<footer>Copyright&copy; Martin Gibbons 2016</footer>
</div>
</div>



</body>
</html>